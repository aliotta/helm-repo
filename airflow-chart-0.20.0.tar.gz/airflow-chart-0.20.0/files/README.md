This dir is used for templates that need to be rendered, but are not meant to be submitted directly to k8s as manifests.
